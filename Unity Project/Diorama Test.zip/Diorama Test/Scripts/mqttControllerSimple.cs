using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mqttControllerSimple : MonoBehaviour
{
    public string nameController = "Controller 1";
    public string tag_mqttManager = "";
    public string topicSubscribed = ""; //the topic to subscribe, it need to match a topic from the mqttManager
    public mqttManager _eventSender;
private float pointerValue = 0.0f;


public GameObject objectToControl; 

  public Animator animator;
    float speed;


   void Awake()
    {
        if (GameObject.FindGameObjectsWithTag(tag_mqttManager).Length > 0)
        {
            _eventSender = GameObject.FindGameObjectsWithTag(tag_mqttManager)[0].gameObject.GetComponent<mqttManager>();
           // _eventSender.Connect(); //Connect the Manager when the object is spawned
        }
        else
        { 
            Debug.LogError("At least one GameObject with mqttManager component and Tag == tag_mqttManager needs to be provided");
        }
    }

    void OnEnable()
    {
        _eventSender.OnMessageArrived += OnMessageArrivedHandler;
        
    }

    private void OnDisable()
    {
        _eventSender.OnMessageArrived -= OnMessageArrivedHandler;
    }

    private void OnMessageArrivedHandler(mqttObj mqttObject) //the mqttObj is defined in the mqttManager.cs
    {
        //We need to check the topic of the message to know where to use it 
        if (mqttObject.topic.Contains(topicSubscribed))
        {
            pointerValue = float.Parse(mqttObject.msg);

if(pointerValue >5){  //original value was 10!
 // speed = 1;
                // animator.SetFloat("AnimationSpeed", speed);
}

if(pointerValue >30){
 // speed = 4;
                // animator.SetFloat("AnimationSpeed", speed);
}

if(pointerValue >10){
 // speed = 1;
                // animator.SetFloat("AnimationSpeed", speed);
}

if(pointerValue <0){
 // speed = 0;
                // animator.SetFloat("AnimationSpeed", speed);
}
               



            Debug.Log("Message, from Topic " + mqttObject.topic + " is = " + mqttObject.msg);
        }
    }

    private void Update()
    {



    }
}