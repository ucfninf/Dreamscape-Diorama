using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class mqttControllerSheep : MonoBehaviour
{
    public string nameController = "Controller 1";
    public string tag_mqttManager = "";
    public string topicSubscribed = ""; // The topic to subscribe, it needs to match a topic from the mqttManager
    public mqttManager _eventSender;
    private float pointerValue = 2.0f;

    public PlayerController playerController; // Reference to PlayerController
    
    public GameObject targetObject; // The target object in the scene that you want the sheep to run to
    public GameObject objectToControl; 
    
    public NavMeshAgent agent;
    public Animator animator;
    
    private Vector3 initialPosition; // Store the initial position
    private Quaternion initialRotation; // Store the initial rotation

    [Header("Animation Settings")]
    public string walkForwardAnimation = "walk_forward";
    public string walkBackwardAnimation = "GoatSheep_walk_backward_RM";
    public string runForwardAnimation = "run_forward";
    public string turn90LAnimation = "turn_90_L";
    public string GoatSheep_eating = "GoatSheep_eating";
    public string turn90RAnimation = "turn_90_R";
    public string trotAnimation = "trot_forward";
    public string sittostandAnimation = "sit_to_stand";
    public string standtositAnimation = "stand_to_sit";

    // Static field to store all sheep instances
    private static List<mqttControllerSheep> allSheep = new List<mqttControllerSheep>();

    void Awake()
    {
        // Store the initial position and rotation of the sheep
        initialPosition = transform.position;
        initialRotation = transform.rotation;

        // Add the current sheep instance to the static list
        allSheep.Add(this);

        // Try to find the mqttManager object by tag
        var mqttManagers = GameObject.FindGameObjectsWithTag(tag_mqttManager);
        Debug.Log("Found " + mqttManagers.Length + " objects with tag " + tag_mqttManager);

        if (mqttManagers.Length > 0)
        {
            _eventSender = mqttManagers[0].GetComponent<mqttManager>();
            if (_eventSender != null)
            {
                // _eventSender.Connect(); // Connect the Manager when the object is spawned, turn this off when MQTT Manager has checked on "Auto Connect"
            }
            else
            {
                Debug.LogError("mqttManager component not found on the object with tag " + tag_mqttManager);
            }
        }
        else
        {
            Debug.LogError("No GameObject with tag " + tag_mqttManager + " found in the scene.");
        }
    }

    void OnEnable()
    {
        if (_eventSender != null)
        {
            _eventSender.OnMessageArrived += OnMessageArrivedHandler;
        }
        else
        {
            Debug.LogError("_eventSender is null in OnEnable. Check if the mqttManager is correctly set.");
        }
    }

    private void OnDisable()
    {
        if (_eventSender != null)
        {
            _eventSender.OnMessageArrived -= OnMessageArrivedHandler;
        }
    }

    private void OnDestroy()
    {
        // Remove the current sheep instance from the static list
        allSheep.Remove(this);
    }

    private void OnMessageArrivedHandler(mqttObj mqttObject)
    {
        Debug.Log("MQTT Message Received: " + mqttObject.msg + " from topic: " + mqttObject.topic);
        
        if (mqttObject.topic.Contains(topicSubscribed))
        {
            if (float.TryParse(mqttObject.msg, out pointerValue))
            {
                Debug.Log("Received sound value: " + pointerValue);

                if (pointerValue > 180)
                {
                    // If the noise value exceeds 180, all sheep run towards the target object
                    AllSheepRunToTarget();
                }
                else if (pointerValue > 150)
                {
                    PlayAnimation(walkForwardAnimation);
                }
                else if (pointerValue > 160)
                {
                    PlayAnimation(trotAnimation);
                }
                else if (pointerValue < 140)
                {
                    PlayAnimation(walkBackwardAnimation);
                }
                else if (pointerValue > 80)
                {
                    PlayAnimation(turn90LAnimation);
                }
                else if (pointerValue > 79)
                {
                    PlayAnimation(GoatSheep_eating);
                }
                else if (pointerValue > 80)
                {
                    PlayAnimation(standtositAnimation);
                }
                else if (pointerValue > 80)
                {
                    PlayAnimation(sittostandAnimation);
                }
                else if (pointerValue > 100)
                {
                    PlayAnimation(turn90RAnimation);
                }
                else if (pointerValue < 60) // When the noise value is less than 60, return to the initial position
                {
                    ReturnToInitialPosition();
                }
                else
                {
                    // Other logic processing
                }
            }
            else
            {
                Debug.LogError("Failed to parse MQTT message as float: " + mqttObject.msg);
            }
        }
    }

    private void PlayAnimation(string animationName)
    {
        if (animator != null)
        {
            Debug.Log("Attempting to play animation: " + animationName);
            animator.Play(animationName);
        }
        else
        {
            Debug.LogError("Animator is not assigned or missing.");
        }
    }

    private void ReturnToInitialPosition()
    {
        if (agent != null)
        {
            agent.SetDestination(initialPosition); // Let the sheep return to the initial position
            Debug.Log("Returning to initial position: " + initialPosition);

            // If needed, play an animation when returning
            PlayAnimation(walkBackwardAnimation);
        }
        else
        {
            Debug.LogError("NavMeshAgent is not assigned.");
        }
    }

    // Static method to make all sheep run towards the target object
    private static void AllSheepRunToTarget()
    {
        foreach (var sheep in allSheep)
        {
            if (sheep.agent != null && sheep.targetObject != null)
            {
                sheep.agent.SetDestination(sheep.targetObject.transform.position);
                sheep.PlayAnimation(sheep.runForwardAnimation);
                Debug.Log("Sheep is running to target: " + sheep.targetObject.name);
            }
        }
    }
}
