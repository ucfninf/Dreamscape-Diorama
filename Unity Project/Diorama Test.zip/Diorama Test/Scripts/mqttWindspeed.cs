using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mqttWindspeed : MonoBehaviour
{
    public string nameController = "Controller 1";
    public string tag_mqttManager = "";
    public string topicSubscribed = ""; // the topic to subscribe, it needs to match a topic from the mqttManager
    public mqttManager _eventSender;
    private float pointerValue = 0.0f;

    public GameObject objectToControl; 
    public Animator animator;
    
    void Awake()
    {
        if (GameObject.FindGameObjectsWithTag(tag_mqttManager).Length > 0)
        {
            _eventSender = GameObject.FindGameObjectsWithTag(tag_mqttManager)[0].gameObject.GetComponent<mqttManager>();
            //_eventSender.Connect(); // Connect the Manager when the object is spawned,turn on only if mqttManger unchecks autoconnect
        }
        else
        { 
            Debug.LogError("At least one GameObject with mqttManager component and Tag == tag_mqttManager needs to be provided");
        }
    }

    void OnEnable()
    {
        _eventSender.OnMessageArrived += OnMessageArrivedHandler;
    }

    private void OnDisable()
    {
        _eventSender.OnMessageArrived -= OnMessageArrivedHandler;
    }

    private void OnMessageArrivedHandler(mqttObj mqttObject) // the mqttObj is defined in the mqttManager.cs
    {
        // We need to check the topic of the message to know where to use it 
        if (mqttObject.topic.Contains(topicSubscribed))
        {
            pointerValue = float.Parse(mqttObject.msg);

            // Adjust animation speed based on the received value
            if (pointerValue < 5)
            {
                animator.SetFloat("AnimationSpeed", 0.5f);
            }
            else if (pointerValue > 13)
            {
                animator.SetFloat("AnimationSpeed", 2.0f);
            }
            else
            {
                animator.SetFloat("AnimationSpeed", 1.0f); // Default to normal speed if value is between 5 and 13
            }

            Debug.Log("Message, from Topic " + mqttObject.topic + " is = " + mqttObject.msg);
        }
    }

    private void Update()
    {
        // You can implement additional logic in Update if necessary
    }
}
