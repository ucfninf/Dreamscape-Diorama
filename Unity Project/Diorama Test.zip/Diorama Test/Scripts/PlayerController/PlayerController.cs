using UnityEngine;
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{
    public NavMeshAgent agent;
    public Camera cam;

    // Update is called once per frame
    void Update()
    {
        // 鼠标点击逻辑，如果MQTT控制不工作，仍然可以通过点击控制
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                // 让代理移动到点击的位置
                agent.SetDestination(hit.point);
                Debug.Log("Moving agent to clicked position: " + hit.point);
            }
        }
    }

    // 用于根据MQTT消息移动到目标对象
    public void MoveToObject(Vector3 targetPosition)
    {
        if (agent != null)
        {
            NavMeshHit hit; // 确保目标位置在导航网格上
            if (NavMesh.SamplePosition(targetPosition, out hit, 1.0f, NavMesh.AllAreas))
            {
                agent.SetDestination(hit.position);
                Debug.Log("Moving agent to target object at position: " + hit.position);
            }
            else
            {
                Debug.LogWarning("Target position is not on the NavMesh.");
            }
        }
        else
        {
            Debug.LogError("NavMeshAgent is not assigned.");
        }
    }
}
