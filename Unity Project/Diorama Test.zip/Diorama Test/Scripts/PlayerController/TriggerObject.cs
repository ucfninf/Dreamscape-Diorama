using UnityEngine;
using UnityEngine.AI;

public class TriggerController : MonoBehaviour
{
    public NavMeshAgent agent;  // 引用NavMeshAgent对象
    public Transform destination;  // 目标位置
    public Camera cam;  // 摄像机引用

    // 当另一个Collider进入触发器时调用此方法
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player entered the trigger area.");
            if (agent != null && destination != null)
            {
                agent.SetDestination(destination.position);  // 设置目标位置
            }
        }
    }

    // 当另一个Collider退出触发器时调用此方法
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player exited the trigger area.");
            if (agent != null)
            {
                agent.ResetPath();  // 停止移动
            }
        }
    }

    // 其他与摄像机相关的逻辑代码...
    void Update()
    {
        // 例如摄像机的移动或旋转逻辑
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                // 如果需要保留鼠标点击控制NavMeshAgent，可以保留此逻辑
                agent.SetDestination(hit.point);
            }
        }

        // 其他摄像机相关的逻辑
    }
}
