using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float Speed = 3;
    public float Eat = 0;

    Animator SheepMove;

    Vector3 move;

    // Start is called before the first frame update
    void Start()
    {
        SheepMove = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float x= Input.GetAxis("Horizontal");
        float z= Input.GetAxis("Vertical");

        Vector3 move = new Vector3(x,0,z);

        
        transform.LookAt (transform.position + new Vector3 (x, 0, z));
        transform.position += new Vector3(x,0,z) * Speed * Time.deltaTime;


    }

    void UpdateSheepMove()
    {
        SheepMove.SetFloat ("Speed", move.magnitude);
    }
}
