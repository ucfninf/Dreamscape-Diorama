using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateAroundObject : MonoBehaviour
{
    public Transform targetObject;  // 中心物体的Transform
    public float rotationDuration = 10f;  // 每180度旋转的时间
    private float rotationAngle = 180f;  // 总旋转角度180度
    private float currentAngle = 0f;     // 当前旋转角度
    private float rotationSpeed;         // 旋转速度

    private void Start()
    {
        // 计算旋转速度
        rotationSpeed = rotationAngle / rotationDuration;
    }

    private void Update()
    {
        // 计算每帧旋转的角度
        float angleThisFrame = rotationSpeed * Time.deltaTime;

        // 更新当前旋转角度
        currentAngle += angleThisFrame;

        // 如果当前角度超过目标角度，重置旋转
        if (currentAngle >= rotationAngle)
        {
            currentAngle = 0f;
        }

        // 旋转摄像机
        transform.RotateAround(targetObject.position, Vector3.up, angleThisFrame);
    }
}